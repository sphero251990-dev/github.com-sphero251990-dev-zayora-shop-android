const products=[
{id:1,name:"UGREEN iPhone MagSafe Clear Non-yellowing Case",cat:"Accessories",price:1290,old:1590,rating:4.8,img:"assets/ugreen-1.jpg",seller:"Zayora Official",stock:20},
{id:2,name:"Apple iPhone 18 Pro Max 2TB — Glacier",cat:"Mobile",price:299990,old:319990,rating:4.9,img:"assets/iphone-1.jpg",seller:"Zayora Official",stock:5},
{id:3,name:"UGREEN MagSafe Clear Case Premium",cat:"Accessories",price:1490,old:1790,rating:4.7,img:"assets/ugreen-2.jpg",seller:"Zayora Official",stock:12},
{id:4,name:"iPhone 18 Pro Max — Deep Red",cat:"Mobile",price:299990,old:319990,rating:4.9,img:"assets/iphone-3.jpg",seller:"Zayora Official",stock:4}];
let all=JSON.parse(localStorage.getItem("zayora_products")||"null")||products;
let cart=JSON.parse(localStorage.getItem("zayora_cart")||"[]");
function save(){localStorage.setItem("zayora_products",JSON.stringify(all));localStorage.setItem("zayora_cart",JSON.stringify(cart));updateCount()}
function updateCount(){let n=cart.reduce((a,x)=>a+x.qty,0);document.querySelectorAll("#cartCount").forEach(e=>e.textContent=n)}
function render(list=all){let g=document.getElementById("grid");if(!g)return;g.innerHTML=list.map(p=>`<article class="card" onclick="openProduct(${p.id})"><img src="${p.img}" onerror="this.src='assets/iphone-1.jpg'"><div class="info"><div class="rating">★ ${p.rating} • ${p.seller}</div><h3>${p.name}</h3><span class="price">৳${p.price.toLocaleString()}</span><span class="old">৳${p.old.toLocaleString()}</span></div><button class="add" onclick="event.stopPropagation();addCart(${p.id})">🛒 Add to Cart</button></article>`).join("")||'<div class="empty">কোনো পণ্য পাওয়া যায়নি</div>'}
function addCart(id){let p=all.find(x=>x.id==id),x=cart.find(x=>x.id==id);if(x)x.qty++;else cart.push({id,qty:1});save();toast("কার্টে যোগ হয়েছে")}
function openProduct(id){location.href="product.html?id="+id}
function filterCat(c){let l=c==="All"?all:all.filter(p=>p.cat===c);render(l);document.getElementById("products")?.scrollIntoView({behavior:"smooth"})}
function searchProducts(){let q=document.getElementById("search").value.toLowerCase();render(all.filter(p=>(p.name+" "+p.cat+" "+p.seller).toLowerCase().includes(q)))}
function toggleCats(){document.getElementById("cats").classList.toggle("hide")}
function toast(t){let e=document.getElementById("toast");e.textContent=t;e.style.display="block";setTimeout(()=>e.style.display="none",1800)}
function showAccount(){alert("Customer account: এই demo version-এ login/order data browser-এ সংরক্ষিত হয়। Production version-এ Supabase Auth যুক্ত করতে হবে।")}
updateCount();render();