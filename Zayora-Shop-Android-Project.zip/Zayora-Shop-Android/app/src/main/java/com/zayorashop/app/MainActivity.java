package com.zayorashop.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle b){ super.onCreate(b); web=new WebView(this); setContentView(web);
        web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true); web.getSettings().setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ return openExternal(r.getUrl().toString()); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String u){ return openExternal(u); }
        });
        web.loadUrl("file:///android_asset/index.html");
    }
    private boolean openExternal(String u){
        if(u.startsWith("https://wa.me/") || u.startsWith("whatsapp://") || u.startsWith("tel:") || u.startsWith("mailto:")){
            try{ startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); }catch(Exception ignored){}
            return true;
        }
        return false;
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
