# Zayora Shop Android App

Android Studio project for the Zayora Shop customer app.

- Package: `com.zayorashop.app`
- Offline bundled storefront based on the Zayora Daraz-style prototype.
- WhatsApp/tel/mail links open outside the WebView.
- This source project is buildable in Android Studio with Android SDK 35 and AGP 8.6.1.

To build: open the folder in Android Studio, allow Gradle sync, then Build > Build APK(s).
